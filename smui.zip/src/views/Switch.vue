<template>
  <div class="page">

    <h4>开关</h4>
    <div class="item">
        <sm-switch v-model="state1"></sm-switch><span>{{state1}}</span>
    </div>
    <div class="item">
        <sm-switch v-model="state2"></sm-switch><span>{{state2}}</span>
    </div>

    <h4>禁止开关</h4>
    <div class="item">
        <sm-switch v-model="state1" disabled></sm-switch><span>{{state1}}</span>
    </div>
    <div class="item">
        <sm-switch v-model="state2" disabled></sm-switch><span>{{state2}}</span>
    </div>

  </div>
</template>

<script>
export default {
  name: 'home',
  data:()=>{
    return {
      state1:false,
      state2:true,
    }
  },
  methods:{

  }
}
</script>

<style lang="less">
    .page {
        text-align: left;
        padding:20px;
        h4 {
            color:#999;
            text-align: center;
            margin:20px 0 8px 0;
        }
        .item {
          display: flex;align-items: center;
          margin:8px 0;
          span {
             margin-left:8px;
          }
        }

    }
</style>
