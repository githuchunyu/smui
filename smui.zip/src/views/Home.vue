<template>
  <div id="home">
    <h2>布局组件</h2>
    <sm-cell title="header" :to="{name:'header'}"></sm-cell>
    <sm-cell title="tabbar" :to="{name:'tabbar'}"></sm-cell>
    <h2>互动组件</h2>
    <sm-cell title="button" :to="{name:'button'}"></sm-cell>
    <h2>弹出组件</h2>
    <sm-cell title="toast" :to="{name:'toast'}"></sm-cell>
    <sm-cell title="indicator" :to="{name:'indicator'}"></sm-cell>
    <h2>表单组件</h2>
    <sm-cell title="switch" :to="{name:'switch'}"></sm-cell>
    <sm-cell title="checklist" :to="{name:'checklist'}"></sm-cell>
    <sm-cell title="radio" :to="{name:'radio'}"></sm-cell>
    <sm-cell title="field" :to="{name:'field'}"></sm-cell>
  </div>
</template>

<script>
export default {
  name: 'home',

}
</script>

<style lang="less">
  #home {
    background: #fafafa;
    height:100%;overflow-y: auto;
  }
  h2 {
    padding:24px 0;
  }
</style>
