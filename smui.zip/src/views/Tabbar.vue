<template>
  <div class="page">
    <div class="tabs">
      <div class="tab" v-if="i==activeIndex" v-for="(c,i) in tabcons" :key="c.con">{{c.con}}</div>
    </div>
    <sm-tabbar :list="tabs" v-model="activeIndex"></sm-tabbar>
  </div>
</template>

<script>
export default {
  name: 'toast',
  data:()=>{
    return {
      tabcons:[
        {con:1},{con:2},{con:3},{con:4}
      ],
      tabs:[
        {title:'主页',type:'icon',value:'home'},
        {title:'发现',type:'icon',value:'home'},
        {title:'专题',type:'icon',value:'home'},
        {title:'我的',type:'icon',value:'home'}
      ],
      activeIndex:0,
    }
  },
  methods:{

  }
}
</script>

<style lang="less">
    .page {
        text-align: left;
        h4 {
            color:#999;
            text-align: center;
            margin:20px 0 8px 0;
        }
    }
</style>
