export { default } from './switch.vue';
