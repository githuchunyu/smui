import Header from './header';
import Button from './button';
import Cell from './cell';
import Icon from './icon';
// import CellSwipe from '../packages/cell-swipe';
import Field from './field';
// import Badge from '../packages/badge';
import Switch from './switch';
// import Spinner from '../packages/spinner';
// import TabItem from '../packages/tab-item';
// import TabContainerItem from '../packages/tab-container-item';
// import TabContainer from '../packages/tab-container';
// import Navbar from '../packages/navbar';
import Tabbar from './tabbar';
// import Search from '../packages/search';
import Checklist from './checklist';
import Radio from './radio';
// import Loadmore from '../packages/loadmore';
// import Actionsheet from '../packages/actionsheet';
// import Popup from '../packages/popup';
// import Swipe from '../packages/swipe';
// import SwipeItem from '../packages/swipe-item';
// import Range from '../packages/range';
// import Picker from '../packages/picker';
// import Progress from '../packages/progress';
import Toast from './toast';
import Indicator from './indicator';
// import MessageBox from '../packages/message-box';
// import InfiniteScroll from '../packages/infinite-scroll';
// import Lazyload from '../packages/lazyload';
// import DatetimePicker from '../packages/datetime-picker';
// import IndexList from '../packages/index-list';
// import IndexSection from '../packages/index-section';
// import PaletteButton from '../packages/palette-button';
// import '../src/assets/font/iconfont.css';
// import merge from './utils/merge';

const version = '0.0.1';
const install = function(Vue, config = {}) {
  if (install.installed) return;

  Vue.component('sm-header', Header);
  Vue.component('sm-button', Button);
  Vue.component('sm-cell', Cell);
  Vue.component('sm-icon',Icon);
  // Vue.component(CellSwipe.name, CellSwipe);
  Vue.component('sm-field', Field);
  // Vue.component(Badge.name, Badge);
  Vue.component('sm-switch', Switch);
  // Vue.component(Spinner.name, Spinner);
  // Vue.component(TabItem.name, TabItem);
  // Vue.component(TabContainerItem.name, TabContainerItem);
  // Vue.component(TabContainer.name, TabContainer);
  // Vue.component(Navbar.name, Navbar);
  Vue.component('sm-tabbar', Tabbar);
  // Vue.component(Search.name, Search);
  Vue.component('sm-checklist', Checklist);
  Vue.component('sm-radio', Radio);
  // Vue.component(Loadmore.name, Loadmore);
  // Vue.component(Actionsheet.name, Actionsheet);
  // Vue.component(Popup.name, Popup);
  // Vue.component(Swipe.name, Swipe);
  // Vue.component(SwipeItem.name, SwipeItem);
  // Vue.component(Range.name, Range);
  // Vue.component(Picker.name, Picker);
  // Vue.component(Progress.name, Progress);
  // Vue.component(DatetimePicker.name, DatetimePicker);
  // Vue.component(IndexList.name, IndexList);
  // Vue.component(IndexSection.name, IndexSection);
  // Vue.component(PaletteButton.name, PaletteButton);
  // Vue.use(InfiniteScroll);
  // Vue.$messagebox = Vue.prototype.$messagebox = MessageBox;
  Vue.$toast = Vue.prototype.$toast = Toast;
  Vue.$indicator = Vue.prototype.$indicator = Indicator;
};

// auto install
if (typeof window !== 'undefined' && window.Vue) {
  install(window.Vue);
};

export default {
  install,
  version,
  // Header,
  // Button,
  // Cell,
  // CellSwipe,
  // Field,
  // Badge,
  // Switch,
  // Spinner,
  // TabItem,
  // TabContainerItem,
  // TabContainer,
  // Navbar,
  // Tabbar,
  // Search,
  // Checklist,
  // Radio,
  // Loadmore,
  // Actionsheet,
  // Popup,
  // Swipe,
  // SwipeItem,
  // Range,
  // Picker,
  // Progress,
  // Toast,
  // Indicator,
  // MessageBox,
  // InfiniteScroll,
  // Lazyload,
  // DatetimePicker,
  // IndexList,
  // IndexSection,
  // PaletteButton
};
