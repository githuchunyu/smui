export { default } from './icon.vue';
