export { default } from './checklist.vue';
