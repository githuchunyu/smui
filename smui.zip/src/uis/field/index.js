export { default } from './field.vue';
