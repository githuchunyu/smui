import Vue from 'vue'
import Router from 'vue-router'

import Home from '@/views/Home'
import Button from '@/views/Button'
import Toast from '@/views/Toast'
import Indicator from '@/views/Indicator'
import Header from '@/views/Header'
import Tabbar from '@/views/Tabbar'
import Switch from '@/views/Switch'
import Checklist from '@/views/Checklist'
import Radio from '@/views/Radio'
import Field from '@/views/Field'

Vue.use(Router)

export default new Router({
	mode: 'history',
	base: '/',
	routes: [

    {path:'/',redirect:'/home'},
    {path:'/home',name:'home',component:Home},
    {path:'/button',name:'button',component:Button},
    {path:'/toast',name:'toast',component:Toast},
    {path:'/header',name:'header',component:Header},
    {path:'/tabbar',name:'tabbar',component:Tabbar},
    {path:'/indicator',name:'indicator',component:Indicator},
		{path:'/switch',name:'switch',component:Switch},
		{path:'/checklist',name:'checklist',component:Checklist},
		{path:'/radio',name:'radio',component:Radio},
		{path:'/field',name:'field',component:Field},

    // {path: '/404',name: '404',component: NotFoundPage},
    // {path: '/*',redirect: '/404'},
	]
})
